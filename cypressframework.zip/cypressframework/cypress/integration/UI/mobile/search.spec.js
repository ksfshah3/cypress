/// <reference types="cypress" />
const { HomePage } = require("../../../support/pages/HomePage");

// @ts-ignore
//const data1 = require('../fixtures/data')
Cypress.on('uncaught:exception', (err, runnable) =>{
    return false;
})

describe("search product <mobile>", {tags: 'regression'}, function(){

    beforeEach(function () { 
        cy.viewport('iphone-x');      
        cy.visit('/');
        cy.fixture('keywords').then((data) => {
            this.key = data;
        })
    })

    it('search product one',{tags: 'smoke'}, function () { 
        cy.log(this.key.Product);
        const homePage =  new HomePage();
        homePage.searchProduct(this.key.Product);
        homePage.clickSearchButton();
    });

    it('search product Two',{tags: 'regression'}, function () { 
        cy.log(this.key.Product);
        const homePage =  new HomePage();
        homePage.searchProduct(this.key.ProductTwo);
        homePage.clickSearchButton();
    });

    it('search product Three',{tags: 'smoke'}, function () { 
        cy.log(this.key.Product);
        const homePage =  new HomePage();
        homePage.searchProduct(this.key.ProductThree);
        homePage.clickSearchButton();
    });
});