/// <reference types="cypress" />
const { HomePage } = require("../../../support/pages/HomePage");

// @ts-ignore
//const data1 = require('../fixtures/data')
Cypress.on('uncaught:exception', (err, runnable) =>{
    return false;
})

describe("search product <desktop>", {tags: 'smoke'}, function(){

    beforeEach(function () {        
        cy.viewport('macbook-16');
        cy.visit('/');
        cy.fixture('keywords').then((data) => {
            this.key = data;
        })
    })

    it('search product one', {tags: 'smoke'}, function () { 
        cy.log(this.key.Product);
        const homePage =  new HomePage();
        homePage.searchProduct(this.key.Product);
        homePage.clickSearchButton();
    });

    it.only('search product Two',{tags: 'regression'}, function () { 
        const homePage =  new HomePage();
        cy.percySnapshot();
        homePage.searchProduct(this.key.ProductTwo);
        homePage.clickSearchButton();
        cy.percySnapshot();
    });

    it('search product Three',{tags: 'smoke'}, function () { 
        cy.log(this.key.Product);
        const homePage =  new HomePage();
        homePage.searchProduct(this.key.ProductThree);
        homePage.clickSearchButton();
    });
});