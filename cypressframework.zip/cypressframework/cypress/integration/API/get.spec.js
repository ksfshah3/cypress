var MethodType = require('../../support/utils/requestHandler/Method_Types');
var UrlPath = require('../../support/utils/requestHandler/UrlPath');
var statusCode = require('../../support/utils/requestHandler/http_status_code');
var sender = require('../../support/utils/requestHandler/requestSender');
var validation_helper = require('../../support/utils/coreHandler/validationHelper');
var logs = require('../../support/utils/coreHandler/logs');

describe("GET request <api>", {tags: 'smoke'}, () => {
    var apiEndPointUrl = Cypress.config().apiUrl;
    var response;

    it.skip('make a get request and check the status code', () => {
        cy.api({
            method: MethodType.GET,
            url: apiEndPointUrl+UrlPath.getUsers
        }).then((response) => {
            expect(response.status).equals(statusCode.OK);
            expect(response.duration).to.not.greaterThan(1000)

        })
    })

    it('make a get request through request sender and check the status code', async () => {
        response  = await sender.sendRequest(
            MethodType.GET,
            apiEndPointUrl+UrlPath.getUsers,
        );
        // responseTime = await sender.fetchResponseTime();
        await validation_helper.validateStatusCodeAndMessageForGET(response)
    })
})