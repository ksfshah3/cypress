var MethodType = require('../../support/utils/requestHandler/Method_Types');
var UrlPath = require('../../support/utils/requestHandler/UrlPath');
var statusCode = require('../../support/utils/requestHandler/http_status_code');
var postSchema = require('../../fixtures/JsonSchema/postJsonSchema.json');
var sender = require('../../support/utils/requestHandler/requestSender');
var validation_helper = require('../../support/utils/coreHandler/validationHelper');

describe("POST request <api>", {tags: 'smoke'}, () => {
    var apiEndPointUrl = Cypress.config().apiUrl;
    var InputJson = require('../../fixtures/testdata/apiRequest/apiRequest.json');
    var response;

    it('make a post request and check the status code', () => {
        cy.api({
            method: MethodType.POST,
            url: apiEndPointUrl+UrlPath.postUsers,
            body: {
                userId: 1,
                title: 'foo',
                body: 'var'
            }
        }).then((response) => {
            expect(response.status).to.equal(statusCode.Created);
            expect(response.body.id).to.equals(101)
            //schema validation
            expect(response.body).to.be.jsonSchema(postSchema)
        })
    });

    it('make a post request through request sender and check the status code', async () => {
        response  = await sender.sendRequest(
            MethodType.POST,
            apiEndPointUrl+UrlPath.postUsers,
            InputJson
        );
        // responseTime = await sender.fetchResponseTime();
        await validation_helper.validateStatusCodeAndMessageForPOST(response)
    })
})