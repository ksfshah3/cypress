var MethodType = require('../../support/utils/requestHandler/Method_Types');
var UrlPath = require('../../support/utils/requestHandler/UrlPath');
var statusCode = require('../../support/utils/requestHandler/http_status_code')

describe("DELETE request <api>", {tags: 'smoke'}, () => {
    var apiEndPointUrl = Cypress.config().apiUrl;

    it('make a DELETE request and check the status code', () => {
        cy.api({
            method: MethodType.DELETE,
            url: apiEndPointUrl+UrlPath.deleteUsers,
        }).then((response) => {
            expect(response.status).to.equal(statusCode.OK);
        })
    })
})