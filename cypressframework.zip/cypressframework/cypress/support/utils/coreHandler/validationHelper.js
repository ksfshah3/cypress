var http_status_code = require('../requestHandler/http_status_code');
var http_status_message = require('../requestHandler/http_status_message');
var Logs = require('./logs');
var {expect} = require('chai');

var validateStatusCodeAndMessageForGET = async function(response){
    return new Promise(function(resolve){
        expect(response.status).to.eql(http_status_code.OK);
        resolve(true);
    }
)}

var validateStatusCodeAndMessageForPOST = async function(response){
    return new Promise(function(resolve){
        expect(response.status).to.eql(http_status_code.Created);
        resolve(true);
    }
)}

module.exports = {
    validateStatusCodeAndMessageForGET, validateStatusCodeAndMessageForPOST
}