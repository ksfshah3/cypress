var Logs = require("mochawesome/addContext");

module.exports = {
    logMessage: async function(context, message){
        Logs(context, message)
    }
}