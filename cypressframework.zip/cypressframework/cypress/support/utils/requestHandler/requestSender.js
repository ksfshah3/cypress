var Logs  = require('../coreHandler/logs');
let ResposneTimeValue;

var saveResponseTime = async function(time){
    ResposneTimeValue=time;
}

var fetchResponseTime =  async function(){
    return new Promise(function(resolve){
        resolve(ResposneTimeValue)
    })
}

var sendRequest = async function(requestType, endPoint, requestBody) {
    return new Promise(function(resolve, reject){
        let result = null;
        if(requestType === 'GET'){
            result = cy.api({
                method: requestType,
                url: endPoint
            })
            .then((response) => {
                cy.log( "ResponseCode "+ response.status)
                resolve(response)
            }, (error) =>{
                cy.log("API threw the following error: "+error)
                reject(error);
            })
        }else if(requestType === 'DELETE'){
            result = cy.api({
                method: requestType,
                url: endPoint
            })
            .then((response) => {
                cy.log( "ResponseCode "+ response.status)
                resolve(response)
            }, (error) =>{
                cy.log("API threw the following error: "+error)
                reject(error);
            })
        }else if(requestType === 'POST'){
            result = cy.api({
                method: requestType,
                url: endPoint,
                body: requestBody
            })
            .then((response) => {
                cy.log( "ResponseCode "+ response.status)
                resolve(response)
            }, (error) =>{
                cy.log("API threw the following error: "+error)
                reject(error);
            })
        }
        return result;
    })
}

module.exports = {
    saveResponseTime, fetchResponseTime, sendRequest
}