module.exports={
    getUsers: "/users",
    postUsers: "/posts?userId=1",
    deleteUsers: "/posts/1"

}