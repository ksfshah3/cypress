var GET = "GET";
var POST = "POST";
var PUT = "PUT";
var DELETE = "DELETE";

module.exports = {
    GET, POST, PUT, DELETE
}