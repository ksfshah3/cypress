module.exports={
    OK: "OK",
    NotFound: "Not Found",
    NoContent: "No Content"
}