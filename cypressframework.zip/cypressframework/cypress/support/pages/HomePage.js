class HomePage {

    async searchProduct(product){
        await cy.get('[id="searchInputId"]').should('be.visible').type(product);
    }

    async clickSearchButton(){
        try {
            await cy.get('[data-automation-id="searchIconBlock"]').should('be.visible').click()
        } catch (error) {
            cy.log("error during click on search button")
        }
    }
} 

module.exports.HomePage = HomePage;